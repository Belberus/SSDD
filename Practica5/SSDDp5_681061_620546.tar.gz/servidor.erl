%% AUTOR : Ana Lasheras Mas 
%% NIA : 620546
%% AUTOR: Alberto Martinez Menendez
%% NIA: 681061
%% FICHERO: servidor.erl
%% TIEMPO: 8 horas
%% DESCRIPCION: Módulo que representa al gestor del servidor de vistas.
%% 				se encarga de mantener el sistema a pesar de los fallos.

%% ---------------------------------------------------------------------
%% servidor : Modulo servidor de vistas
%%
%% ---------------------------------------------------------------------

-module(servidor).
-include("sv.hrl").
-include_lib("eunit/include/eunit.hrl").

-export([start/2, stop/1]).

-export([init_sv/0, init_monitor/0]).

%% Registro que guarda el estado del servidor de vistas
-record(estado_sv, {
	vistaValida::vista:vista(), 
	vistaTentativa::vista:vista(),
	pings::dict() %%Lista con tuplas {@nodo, nPingsFallados}
}).

%%%%%%%%%%%%%%%%%%%% Interface (FUNCIONES EXPORTABLES)  %%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Poner en marcha el servicio de vistas con 2 procesos concurrentes
-spec start( atom(), atom() ) -> node().
start(Host, NombreNodo) ->
	% ?debugFmt("Arrancar un nodo servidor vistas~n",[]),
	% args para comando remoto erl
	Args = "-connect_all false -setcookie palabrasecreta",
	% arranca servidor en nodo remoto
	{ok, Nodo} = slave:start(Host, NombreNodo, Args),
	%  ?debugFmt("Nodo servidor vistas en marcha : ~p~n",[Nodo]),
	process_flag(trap_exit, true),
	spawn_link(Nodo, ?MODULE, init_sv, []),
	Nodo.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parar nodo servidor de vista al completo, includos los 2 procesos
-spec stop( atom() ) -> ok.
	stop(Nodo) ->
	slave:stop(Nodo),
	timer:sleep(10),
	comun:vaciar_buzon(),
	ok.



%%---------------------  FUNCIONES LOCALES  --------------------------%%

%%--------------------------------------------------------------------%%
init_sv() ->
	register(sv, self()),
	spawn_link(?MODULE, init_monitor, []),

	%%Incializa el registro que almacena el estado del sistema
	SV = #estado_sv{
		vistaValida = vista:vista_inicial(),
		vistaTentativa = vista:vista_inicial(),
		pings=dict:new()
	},  
	bucle_recepcion(SV).

%%Funcion que actualiza la vista tentativa si entra un nuevo nodo, o 
%% pasa vista tentativa a valida si primario confirma    
act_listaNodos(SV, NodoOrigen, 0) ->
case vista:primario(SV#estado_sv.vistaTentativa) =:= undefined of
true -> 
	case vista:copia(SV#estado_sv.vistaTentativa) =:= undefined of
	true ->
		Primario = NodoOrigen,
		SV2=SV#estado_sv{vistaTentativa=(vista:nueva_vista
		  (vista:num_vista(SV#estado_sv.vistaTentativa)+1, Primario,
		   vista:copia(SV#estado_sv.vistaTentativa)))},
		SV3=SV2#estado_sv{pings=dict:store(NodoOrigen,0, SV2#estado_sv.pings)},
		{cliente, NodoOrigen} ! {vista_tentativa, SV3#estado_sv.vistaTentativa, true},
		SV3;
	false -> 
		SV
	end;
false -> 
	case NodoOrigen =:= vista:primario(SV#estado_sv.vistaTentativa) of
	true -> SV2=SV#estado_sv{vistaValida=SV#estado_sv.vistaTentativa},
		{cliente, NodoOrigen} ! {vista_tentativa, SV2#estado_sv.vistaTentativa, true},
		SV2;
	false ->
		case vista:copia(SV#estado_sv.vistaTentativa) =:= undefined of
		true -> Copia = NodoOrigen,
			SV2=SV#estado_sv{vistaTentativa=(vista:nueva_vista(
			  vista:num_vista(SV#estado_sv.vistaTentativa)+1, 
			  vista:primario(SV#estado_sv.vistaTentativa), Copia))},
			SV3=SV2#estado_sv{pings=dict:store(NodoOrigen,0,SV2#estado_sv.pings)},
			{cliente, NodoOrigen} ! {vista_tentativa, SV3#estado_sv.vistaTentativa, true},
			SV3;
		false -> SV2=SV#estado_sv{pings=dict:store(NodoOrigen,0,SV#estado_sv.pings)},
			{cliente, NodoOrigen} ! {vista_tentativa, SV2#estado_sv.vistaTentativa, true},
			SV2
		end
	end
end;

act_listaNodos(SV, NodoOrigen, NumVista) ->
SV2 = SV#estado_sv{pings=(dict:store(NodoOrigen, 0, SV#estado_sv.pings))},
case NodoOrigen =:= vista:primario(SV2#estado_sv.vistaTentativa) of
false ->   {cliente,NodoOrigen} ! {vista_tentativa, SV2#estado_sv.vistaTentativa, true},
	SV2;
true ->
	case NumVista == vista:num_vista(SV2#estado_sv.vistaTentativa) of
	true ->
		SV3 = SV2#estado_sv{vistaValida=SV2#estado_sv.vistaTentativa},
		{cliente,NodoOrigen} ! {vista_tentativa, SV3#estado_sv.vistaTentativa, true},
		SV3;
	false ->
		{cliente,NodoOrigen} ! {vista_tentativa, SV2#estado_sv.vistaTentativa, true},
		SV2
	end
end.

%%----------------------------------------------------------------------
bucle_recepcion(SV) ->    
receive    
	{ping, NodoOrigen, NumVista} ->   
		%%Llama a funcion que actualiza los nodos y vista tentativa o
		%% valida si es necesario
		%%Devuelve vista tentativa
		SV2=act_listaNodos(SV, NodoOrigen, NumVista),
		bucle_recepcion(SV2); %%Mantiene el estado del sistema

	{obten_vista, Pid} ->
		%%Devuelve vista valida
		Pid ! {vista_valida, SV#estado_sv.vistaValida},
		bucle_recepcion(SV); %%Mantiene el estado del sistema
	procesa_situacion_servidores -> 
		%%Llama a procesar_situacion_servidores
		SV2=procesar_situacion_servidores(SV),
		bucle_recepcion(SV2) %%Mantiene el estado del sistema
end.

%%----------------------------------------------------------------------
init_monitor() ->
sv ! procesa_situacion_servidores,
timer:sleep(?INTERVALO_PING),
init_monitor().

%-----------------------------------------------------------------------
%%Funcion que borra los nodos, que han estado 5 periodos o mas sin hacer
%% ping y por tanto se consideran caidos
nodoCaido([],SV) -> SV;
nodoCaido([X|L], SV) -> case dict:fetch(X,SV#estado_sv.pings) >= 5 of
true ->
	SV2=SV#estado_sv{pings=(dict:erase(X, SV#estado_sv.pings))},
	nodoCaido(L,SV2);
false -> nodoCaido(L,SV)
end.

%%----------------------------------------------------------------------
%%Funcion que devuelve un nodo que se encuentre en la lista indicada en 
%% el primer parametro si es distinto del segundo parametro, sino devuelve
%% undefined
getNodoEspera([], _P) -> undefined;
getNodoEspera([H|L], P) -> if H =/= P -> H;
true -> getNodoEspera(L,P)
end.

%%----------------------------------------------------------------------
%%Funcion que revisa si ha caido un el nodo copia y si es asi actualiza
%% la vista tentativa con un nodo en espera. Al finalizar llama a la
%% funcion primarioCaido
copiaCaido(SV) ->
case dict:is_key(vista:copia(SV#estado_sv.vistaTentativa),SV#estado_sv.pings) of
true ->
	primarioCaido(SV,false);
false ->
	%%No esta el nodo copia --> HA CAIDO
	Keys = dict:fetch_keys(SV#estado_sv.pings),
	 %%Obtengo nuevo nodo en espera para ponerlo en copia
	Copia = getNodoEspera(Keys, vista:primario(SV#estado_sv.vistaTentativa)),
	case Copia =:= vista:copia(SV#estado_sv.vistaTentativa) of 
	true -> 
		primarioCaido(SV,false);
	false ->
		%%Actualizo vista tentativa
		SV2=SV#estado_sv{vistaTentativa=vista:nueva_vista(
		  vista:num_vista(SV#estado_sv.vistaTentativa)+1, 
		  vista:primario(SV#estado_sv.vistaTentativa),Copia)},
		primarioCaido(SV2,true)
	end
end.

%%----------------------------------------------------------------------
%%Funcion que detecta si el nodo primario a caido y si es asi promociona
%% en vista tentativa a copia y modifica copia por un nodo en espera
primarioCaido(SV, Modificado)->
case dict:is_key(vista:primario(SV#estado_sv.vistaTentativa),SV#estado_sv.pings) of
true -> SV;
false ->
	%%No esta el nodo copia --> HA CAIDO
	Primario = vista:copia(SV#estado_sv.vistaTentativa),
	Keys = dict:fetch_keys(SV#estado_sv.pings),
	Copia = getNodoEspera(Keys, Primario), %%Obtengo nuevo nodo en espera
	case Copia =:= vista:copia(SV#estado_sv.vistaTentativa) of 
	true -> 
		SV;
	false ->
		case Modificado of
		true ->
			%%Actualizo vista tentativa NO numVista
			SV2=SV#estado_sv{vistaTentativa=vista:nueva_vista(
			  vista:num_vista(SV#estado_sv.vistaTentativa),Primario,Copia)},
			SV2;
		false ->
			%%Actualizo vista tentativa
			SV2=SV#estado_sv{vistaTentativa=vista:nueva_vista(
			  vista:num_vista(SV#estado_sv.vistaTentativa)+1,Primario,Copia)},
			SV2
		end
	end
end.
%%----------------------------------------------------------------------
%%Funcion que actualiza el numero de latidos no producidos por los nodos
%%"activos" en 1
actualizar_latidos([],1,Dict) -> Dict;
actualizar_latidos([X|L],1,Dict) -> 
	Dict2 = dict:update_counter(X, 1,Dict),
	actualizar_latidos(L,1,Dict2).

%%----------------------------------------------------------------------
%%Funcion que monitoriza el estado del gestor de vistas
procesar_situacion_servidores(SV) ->
%%Aumento el numero de pings a todos los nodos del diccionario "pings"
Keys = dict:fetch_keys(SV#estado_sv.pings),
Dict = actualizar_latidos(Keys,1,SV#estado_sv.pings),

SV2=SV#estado_sv{pings=Dict},

%%Elimino nodos que no han enviado ping tras 5 intervalos de ping
SV3=nodoCaido(Keys, SV2),

%%Mirar si copia ha caido, y si el nodo primario ha caido
SV4=copiaCaido(SV3),		
SV4.
